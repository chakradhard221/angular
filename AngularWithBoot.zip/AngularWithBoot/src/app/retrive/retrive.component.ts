import { Component, OnInit } from '@angular/core';
import {AngularRestService} from '../angular-rest.service';
import { Item } from '../Item';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Rx';
import { analyzeAndValidateNgModules } from '@angular/compiler';
@Component({
  selector: 'app-retrive',
  templateUrl: './retrive.component.html',
  styleUrls: ['./retrive.component.css']
})
export class RetriveComponent implements OnInit {

  constructor(private service:AngularRestService) { }
finalData:Item[];
  ngOnInit() {
    
  }




  onClick(){
    alert("beforeGetData")
 this.service.provideAllData().subscribe(
res=>console.log(JSON.stringify(res)))
}

  finalDt(){
    alert("finalDt......" +this.finalData);

 
    console.log(this.finalData.toString)
  }
}
