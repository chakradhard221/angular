import { TestBed, inject } from '@angular/core/testing';

import { MapTestService } from './map-test.service';

describe('MapTestService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MapTestService]
    });
  });

  it('should be created', inject([MapTestService], (service: MapTestService) => {
    expect(service).toBeTruthy();
  }));
});
