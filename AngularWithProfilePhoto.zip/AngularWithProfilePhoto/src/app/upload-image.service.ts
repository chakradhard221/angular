import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Rx';
import { UploadFileResponse } from './UploadFileResponse';

@Injectable()
export class UploadImageService {
finalUrl:string;
  constructor(private http:HttpClient) { }

createProfile(value){
  alert("....alert...service.."+value)
let db=this.http.post("http://localhost:9001/upload/files/d3f426f9-e818-4b8d-9245-2e49b1426828/per",value);
db.map((res: UploadFileResponse) => console.log(res.fileDownloadUri)).subscribe();
}

deleteProfile(){
alert("...deletingservice....")
let db=this.http.delete("http://localhost:9001/files/d3f426f9-e818-4b8d-9245-2e49b1426828/per/1234 (1).jpeg");
db.subscribe()
}



}
