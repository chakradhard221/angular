import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {

  studentData;
  constructor() { }

  ngOnInit() {
  }

  onsubmit(value:any){
alert("...............parent........")
this.studentData=value
    console.log(JSON.stringify(value))
  }


}
