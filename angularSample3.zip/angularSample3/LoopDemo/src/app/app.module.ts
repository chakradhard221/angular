import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { LoopsComponent } from './loops/loops.component';
import { ArraySam } from './loops/ArraySam';


@NgModule({
  declarations: [
    AppComponent,
    LoopsComponent
    
  ],
  imports: [
    BrowserModule,
    
  ],
  providers: [ArraySam],
  bootstrap: [AppComponent]
})
export class AppModule { }
