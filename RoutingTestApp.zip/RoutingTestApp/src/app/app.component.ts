import { Component } from '@angular/core';
import {RequestOptions, Request, RequestMethod} from '@angular/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
}

// options:RequestOptions
// this.options=new RequestOptions ({headers: this.headers});

// alert("options")