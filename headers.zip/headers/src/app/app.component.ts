import { Component } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'headers';
  catchForm(data:any){
    console.log(JSON.stringify(data));
  // var header = new HttpHeaders().set('Content-Type', 'text/xml');
  var header=new HttpHeaders().append('Content-Type','text/xml')
   alert(JSON.stringify(header));
    console.log(header);
}
}
