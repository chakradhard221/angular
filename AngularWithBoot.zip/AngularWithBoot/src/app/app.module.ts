import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { CreateComponent } from './create/create.component';
import { DeleteComponent } from './delete/delete.component';
import { UpdateComponent } from './update/update.component';
import { RetriveComponent } from './retrive/retrive.component';
import { HomeRoutingModule } from './home-routing/home-routing.module';
import {RouterModule,Routes} from '@angular/router';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http'
import {AngularRestService} from '../app/angular-rest.service';
import { DisplayDataComponent } from './display-data/display-data.component';
import { AddComponent } from './add/add.component';
// import { MultiComponentDataTransferComponent } from './multi-component-data-transfer/multi-component-data-transfer.component'
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    CreateComponent,
    DeleteComponent,
    UpdateComponent,
    RetriveComponent,
    DisplayDataComponent,
    AddComponent,
    // MultiComponentDataTransferComponent,
  
  ],
  imports: [
    BrowserModule,
    HomeRoutingModule,
    RouterModule,
    FormsModule,
    HttpClientModule,


  ],
  providers: [AngularRestService],
  bootstrap: [AppComponent]
})
export class AppModule { }
