var request=require('request-promise');
var cors=require('cors')
var express=require('express')
var bodyParser=require('body-parser')
var app=express();
app.use(express.json());
var server=app.listen('3003',function(){console.log('listening port 3003')})
// app.use(cors())
app.get('/getExchange',runThisCode);
app.get('/getPost',runThisCodePost);
// var options={
//     host:'dev.solitx.io',
//     port:7766,
//     path:'/transactionDetails',
//     method:'POST'
// }
// app.get("/",(req,res)=>{
//     res.send("helloGoodmornig..")
// })
// app.get("/api/npm",(req,res)=>{
//     res.send([1,2,3])
// })
// app.post("/api/name",(req,res)=>{
//     const data={
//         "name":"chakradhar",
//         "number":"123456"
//     };
//     res.send(data)
// })
function runThisCode(req,res){
    console.log("MethodCalling.....")
    // alert("..getExchanged...")
    // res.send('recieved Request')
    request({
        method:'GET',
        resolveWithFullResponse:true,
        // url:'http://test.mobilefirstfinance.com:7766/masterproduct/J'
        url:'https://uat.nsenmf.com/NMFIIService/NMFService/State?BrokerCode=ARN-82172&Appln_Id=MFS82172&Password=Admin@12',
    })
    .then((r1)=>{
        res.send(JSON.stringify(r1.body)) 
    })
    .catch()
}

function runThisCodePost(req,res){
    // res.send('recieved Request')
    request({
        method:'POST',
        resolveWithFullResponse:true,
        url:'http://test.mobilefirstfinance.com:7766/masterproduct/J',
    })
    .then((r1)=>{
        res.send(JSON.stringify(r1.body)) 
    })
    .catch()
}