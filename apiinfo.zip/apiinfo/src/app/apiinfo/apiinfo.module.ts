import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { ValidComponent } from '../valid/valid.component';
import { InValidComponent } from '../in-valid/in-valid.component';


export const routes:Routes=[
  {path:'valid',component:ValidComponent},
  {path:'invalid',component:InValidComponent}
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ]
})
export class ApiinfoModule { }
