export  class UploadFileResponse{
    fileName:any
    fileDownloadUri:any
    fileType:any
    size:any
}