import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
checkBoxFiled:any;
  onSubmitTemplateBased(value: any) {
    alert(JSON.stringify(value))
    console.log(JSON.stringify(value))

  }

  cities = ["hydrabad", "mumbai", "delhi"]
  filterForeCasts(event: any) {
alert(".....evenet...."+event)
  }

  visibility(event:any){
    this.checkBoxFiled=event.target.value;
  }

}