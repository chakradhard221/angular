import { Component } from '@angular/core';
import * as JsonToXML from "js2xmlparser";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'json-xml';
constructor(){

}

submitData(value){

console.log("jsonformat"+JSON.stringify(value))

console.log("xmlFormat..."+JsonToXML.parse('employee',value));

}


  }
 
