import { TestBed } from '@angular/core/testing';

import { SslService } from './ssl.service';

describe('SslService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SslService = TestBed.get(SslService);
    expect(service).toBeTruthy();
  });
});
