import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule,Routes} from '@angular/router';
import { UpdateComponent } from '../update/update.component';
import { CreateComponent } from '../create/create.component';
import { DeleteComponent } from '../delete/delete.component';
import { RetriveComponent } from '../retrive/retrive.component';
// import { HomeComponent } from '../home/home.component';
export const routes:Routes=[
{path:'update',component:UpdateComponent},
{path:'create',component:CreateComponent},
{path:'delete',component:DeleteComponent},
{path:'get',component:RetriveComponent},
// {path:'',component:HomeComponent}
]
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  declarations: []
})
export class HomeRoutingModule { }
