import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes,RouterModule} from "@angular/router"
import {SecondComponent} from "../second/second.component";
import {PreviewComponent} from '../preview/preview.component'
import { FirstComponent } from '../first/first.component';
const routes:Routes=[
{path:'second',component:SecondComponent},
{path:'preview',component:PreviewComponent}
]

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  declarations: []
})
export class ConfigModule { }
