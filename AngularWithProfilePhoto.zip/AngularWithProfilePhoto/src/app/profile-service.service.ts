import { Injectable } from '@angular/core';
import { HttpModule } from '@angular/http';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class ProfileServiceService {

  constructor(private http: HttpClient) { }



  createProfile(value: any) {
    alert("....from..sErvice.." + JSON.stringify(value))

    let db = this.http.post("http://localhost:8001/profile", value).subscribe();
  }

}
