import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UploadImageService } from '../upload-image.service';

@Component({
  selector: 'app-upload-image',
  templateUrl: './upload-image.component.html',
  styleUrls: ['./upload-image.component.css']
})
export class UploadImageComponent implements OnInit {
  myFiles: string[] = [];
  imageFiles: any
  filesToUpload: Array<File> = [];
  // formData:any;
  constructor(private http: HttpClient, private service: UploadImageService) { }



  ngOnInit() {

  }

  selectFile(inputFile:any) {
    this.filesToUpload =<Array<File>> inputFile.target.files;
  }
  
  saveData() {
    let formData = new FormData();
    for (let i = 0; i < this.filesToUpload.length; i++) {
      formData.append('files',  this.filesToUpload[i])
      alert("......." + formData.toString)
    }
    this.service.createProfile(formData)
  }

  deleteProfile(){
    this.service.deleteProfile();
  }
}
