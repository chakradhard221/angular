import { NgModule } from '@angular/core';
import {RouterModule } from '@angular/router';
// import { HomeComponent } from './home/home.component';
// import { NoPageComponent } from './no-page/no-page.component';
// import { IndexComponent } from './index/index.component';
// const routes: Routes = [

//   {path:'index',component:IndexComponent},
//   {path:'home',component:HomeComponent},
//   {path:'**',component:NoPageComponent}
// ];

@NgModule({
  imports: [RouterModule.forRoot([])],
  exports: [RouterModule]
})
export class AppRoutingModule { }
