import { Component } from '@angular/core';
import { RouterLink, Router } from '@angular/router';
import { routes } from './apiinfo/apiinfo.module';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'apiinfo';
constructor( private router:Router){

}

  formData(data){
alert("...send....")
console.log("......"+data.password)
if(data.password=="mff"){
alert("validUser....")
this.router.navigateByUrl('valid')
}
else{
  alert("invaliduser")
  this.router.navigateByUrl('invalid')
}
  }

}
