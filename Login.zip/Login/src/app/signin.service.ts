import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders, HttpRequest} from '@angular/common/http';
// import { Headers, Http, RequestOptions, Response } from '@angular/http';
// import { HttpClientModule, HttpRequest, HttpHeaders,RequestOptions } from "@angular/common/http";
@Injectable({
  providedIn: 'root'
})
export class SigninService {
  private req: HttpRequest<any>;
url:any;
plainCreds:string="web-app:"
  //  private  reqHeaders = new HttpHeaders ({'Content-Type':'application/x-www-form-urlencoded',"Access-Control-Allow-Origin" : '*','Authorization':'Basic'+btoa('web-app:')});
    // private  options = new HttpRequestOptions ({headers: this.reqHeaders});

    private header=  new HttpHeaders({'Content-Type':'application/x-www-form-urlencoded','Authorization':"'Basic'+btoa(this.plainCreds)"});
   
   
    
   
    constructor(private http_client:HttpClient) { 
  }
  callOauth(data:any){
    alert("...headerOne..."+JSON.stringify(this.header))
    const header = new HttpHeaders();
    header.set('Content-Type','application/x-www-form-urlencoded');
    header.set('Authorization','Basic'+btoa(this.plainCreds));
    header.set('Access-Control-Allow-Origin','*');
    alert("..headers22.."+JSON.stringify(header));
    let  options =  ({
      headers: header
    });
    // const httpOptions = new RequestOptions({headers: this.header})
 this.url="https://localhost:5050/oauth/token";
 alert("inservices......"+JSON.stringify(data))
     let jsonObjec:any={
      'grant_type':'password',
      'username':data.userName+','+data.rootUser,
      'password':data.password
      }

    

    alert("dataIn......jsonObject..."+JSON.stringify(jsonObjec))
 
  this.http_client.post(this.url,JSON.stringify(jsonObjec),{
    headers: header
  }).subscribe((res:any)=>{console.log(res)});
  }
 
 
}
