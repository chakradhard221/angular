import { Component, OnInit } from '@angular/core';
import { AngularRestService } from '../angular-rest.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  constructor( private service:AngularRestService) { }

  ngOnInit() {
  }

  userData(value:any){
  alert(JSON.stringify(value))
this.service.createItem(value);
   
  }

}
