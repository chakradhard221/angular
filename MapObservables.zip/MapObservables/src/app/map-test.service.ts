import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Response } from '@angular/http';
import  'rxjs/Rx';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import 'rxjs/observable/throw';

import { HttpErrorResponse } from '@angular/common/http';
@Injectable()
export class MapTestService {

  constructor(private http:HttpClient) { }

dataProcess(){
  return this.http.get("http://localhost:4562/get").map((res:Response)=>res);
}



errorHandler(error:HttpErrorResponse){
// return Observable.throw(error.message||"server error");
}

}
