import { Component, OnInit } from '@angular/core';
import {  FormGroup, FormControl }   from '@angular/forms';
import { PersonalData } from '../../ContactRequest';
@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  contactForm: FormGroup;

  countries = ['USA', 'Germany', 'Italy', 'France'];

  requestTypes = ['Claim', 'Feedback', 'Help Request'];

  constructor() {
    this.contactForm = this.onSubmit();
    
  }


  ngOnInit() {

 
  }







  onSubmit(){
    alert("..............")
    return new FormGroup({
      personalData:new FormGroup(
{
email:new FormControl(),
mobile: new FormControl(),
country: new FormControl()
}),
requestType: new FormControl(),
text: new FormControl()

    })

  }
  onClick(){
    alert(this.contactForm+".........")
    console.log(this.contactForm.touched)
    console.log(PersonalData.toString+"................persdaaat")
  }


}
