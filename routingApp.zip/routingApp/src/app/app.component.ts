import { Component } from '@angular/core';
import { analyzeAndValidateNgModules } from '@angular/compiler';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'routingApp';

  listOfArticles = [, ,]


  //  items = [
  //   { value: 'Login' },
  //   { value: 'SignUp' },
  //   { value: 'Dashboard' }

  // ];

  goData(data) {
    alert("...name..."+data.selectedItems)
  }

}


