export class Person{

name:string
number:number
salary:string


} 