import { BrowserModule } from '@angular/platform-browser';
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { ValidComponent } from './valid/valid.component';
import { InValidComponent } from './in-valid/in-valid.component';
import { ApiinfoModule } from './apiinfo/apiinfo.module';
import {APP_BASE_HREF} from '@angular/common';
import { provideRoutes, ɵROUTER_PROVIDERS } from '@angular/router';

@NgModule({
  declarations: [
    AppComponent,
    ValidComponent,
    InValidComponent
  ],
  // schemas: [NO_ERRORS_SCHEMA],redoc-cli bundle -o
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ApiinfoModule,
  ],
 
  providers: [{provide: APP_BASE_HREF, useValue : '/' }],
  bootstrap: [AppComponent],
 
})
export class AppModule { }
