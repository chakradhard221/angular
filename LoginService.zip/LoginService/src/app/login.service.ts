import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import 'rxjs/Rx';

@Injectable()
export class LoginService {

  constructor(private http:HttpClient) { }


  getAccessToken(value){
alert("..servicess....."+value)
return this.http.post("http://localhost:5055/login",value).map((res:Response)=>console.log(res));
  }


  

}
