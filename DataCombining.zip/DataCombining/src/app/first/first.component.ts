import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {EmployeeService} from '/home/aswindia-23/Desktop/angularSample2/DataCombining/src/app/employee.service'

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent implements OnInit {

  data;
  hiddenForm = false

  constructor(private router:Router ,private service:EmployeeService) { }

  ngOnInit() {

  }

  formData(value) {
    this.hiddenForm = true
    this.data = value
    alert('........................')
    console.log(JSON.stringify(value))
    this.service.firstCompData(value);
    this.router.navigate(['second']);
  }



}
