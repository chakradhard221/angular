import { Routes } from '@angular/router';
import {noPageRoutes} from './no-page/no-page.router';
import {Indexroutes} from './index/index.router';
import {homeRoutes} from './home/home.router';

export const routes:Routes=[

...homeRoutes,...Indexroutes,...noPageRoutes

]