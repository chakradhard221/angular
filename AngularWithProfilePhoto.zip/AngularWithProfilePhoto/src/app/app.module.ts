import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'

import { AppComponent } from './app.component';
// import { CreateProfileComponent } from './create-profile/create-profile.component';
import { ProfileServiceService } from './profile-service.service';
import {HttpModule} from '@angular/http';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { UploadImageComponent } from './upload-image/upload-image.component';
import { UploadImageService } from './upload-image.service';
@NgModule({
  declarations: [
    AppComponent,

    UploadImageComponent,
   
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule
   
  ],
  providers: [ProfileServiceService,HttpClient,UploadImageService],
  bootstrap: [AppComponent]
})
export class AppModule { }
