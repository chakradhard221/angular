export class UserDeatials {

    private userName:string;
    private rootUser:string;
    private password:string;
}
