import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule,Routes, ROUTES} from "@angular/router"
import {PostComponent} from '../post/post.component'


const routes:Routes=[
  { path:'post',component:PostComponent}
  
  ]

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  declarations: []
})




export class EmployeeModule { }
