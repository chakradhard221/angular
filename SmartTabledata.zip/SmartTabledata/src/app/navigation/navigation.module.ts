import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { ProfileDataComponent } from '../profile-data/profile-data.component';
import { StudentComponent } from '../student/student.component';
import { DashBoardComponent } from '../dash-board/dash-board.component';
import { PageNotFoundComponent } from '../page-not-found/page-not-found.component';
import { LoginComponent } from '../login/login.component';


export const routes:Routes=[
  {path:'profile',component:ProfileDataComponent},
  {path:'student' ,component:StudentComponent},
  {path:'dashboard',component:DashBoardComponent},
  { path: 'login', component:LoginComponent },

]


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  declarations: []
})
export class NavigationModule { }


