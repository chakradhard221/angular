export class DummyData{
i:number=null;
    doThings(){

        var i=80;
        let j=100;
        const k=120;

        console.log(i)
        console.log(j)
        console.log(k)
    }

}