export class RefreshToken {
    private refresh_token:string;
}
