import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import {UserForm} from '/home/aswindia-23/Desktop/angularSample2/CustomReactiveForms/src/app/UserForm';
import {CreateUserService} from '/home/aswindia-23/Desktop/angularSample2/CustomReactiveForms/src/app/create-user.service'
import { HttpClientModule              } from '@angular/common/http';
@Component({
  selector: 'app-profile-editor',
  templateUrl: './profile-editor.component.html',
  styleUrls: ['./profile-editor.component.css']
})
export class ProfileEditorComponent implements OnInit {

  constructor(private user:UserForm,private service:CreateUserService) { }

  ngOnInit() {

    this.getData();

     
    
  }


  userForm = new FormGroup({
    uno:new FormControl(),
    name: new FormControl(),
    age: new FormControl(),
    phone:new FormControl()
}); 

userAddress=new FormGroup({
  hno:new FormControl(),
  city:new FormControl(),
  state:new FormControl()
});



onFormSubmit(){
this.user.name=this.userForm.get('name').value
this.user.age=this.userForm.get('age').value
this.user.phone=this.userForm.get('phone').value
this.user.uno=this.userForm.get('uno').value
alert(this.user)
this.service.createUser(this.user);
} 




getData(){

  this.service.getUser();
}

resetForm() { 
  this.userForm.reset();
} 
}
