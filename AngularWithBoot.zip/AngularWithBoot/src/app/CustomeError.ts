export class CustomeError{
    status:number
    error:any
    
}