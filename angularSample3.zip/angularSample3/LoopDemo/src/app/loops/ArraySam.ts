import { Person } from "./Person";
export class ArraySam{



  
 persons:Array<Person>=[
{'name':'chand','number':12,'salary':'34000'},
{'name':'vivek','number':13,'salary':'40000'},

]

}

