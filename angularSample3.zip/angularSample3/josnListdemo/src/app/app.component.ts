import { Component } from '@angular/core';
import { ArraySam } from '../app/ArraySam';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'josnListdemo';
i:any;
data=[];
  constructor(private list:ArraySam){

    this.data=list.myList;
  }
  
  
  getData(){
    for(this.i=0;this.i<this.data.length;this.i++){
alert("...."+JSON.stringify(this.data[this.i]))
    }
  }


}

