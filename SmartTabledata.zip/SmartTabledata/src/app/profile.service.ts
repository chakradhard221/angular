import { Injectable } from '@angular/core';
import {HttpClient } from '@angular/common/http';
import 'rxjs/Rx';


@Injectable()
export class ProfileService {

  constructor(private http:HttpClient) { }
access_token=null;
urls:string="http://localhost:8069/ariadne/tps/api/profiles?access_token=eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1NjAyNTY1MjEsInVzZXJfbmFtZSI6ImY3YzBmOGU5LTUxNmUtNDZjZi05ZDA3LTU1YWM1YmUzNGUwNixST09UVVNFUixmN2MwZjhlOS01MTZlLTQ2Y2YtOWQwNy01NWFjNWJlMzRlMDYsMjEwZGU1Y2MtMGNjOC00Mzg0LWJhYjctNGVkZDdiYmE3YTEwIiwiYXV0aG9yaXRpZXMiOlsiQUxMIl0sImp0aSI6IjU3ZjlkYmExLTRlODQtNGMxMS1iZGIyLTFiNzU1NTRmNDAzZSIsImNsaWVudF9pZCI6IndlYi1hcHAiLCJzY29wZSI6WyJyZWFkIiwid3JpdGUiXX0.fZhGILDLsCpc7sJNHO1HY1ONeDN__G0MR9nMscsbHvdI7RvSN98DIyPaNtwoIynW5ZtivpIEpfnb-xmfphPoQn0KNxfJlc8vg5s32ucdSh8UhSOa9_eTiHiaS_g1zZlq0AhMrd7UeY51hq-bPJoavH14Sb6FZZrK4odmoMph7yVGGEXJjRB9IWiElmFa4CVaH8ai9uGKvIa0FdMa-60r6s3Dknm4j4x7gq75_1WUEWvFTXabwUjSE1VoucqXn2vFzbuBAq_yaSjtpIdFgFIoN6IbDvstpAJDqOfnUryQQQCT04Fgq-k56KLDR_vwsD_RvktRD64d8ERRCy0-b-mKpA";
public provideData(){
return this.http.get(this.urls).map((res:Array<Response>)=>res);
}



postData(){
  this.http.post("http://localhost:4562/gd",{
    "sname":"chakradhar",
    "sno":"12563"
  }).subscribe();
}

public getData(){

  return this.http.get("http://localhost:4562/get").map((res:Array<Response>)=>res);
//  return this.http.get("http://localhost:4562/get").map((res:Response)=>res);
}


 getToken(value:any){
alert("service..in...value.."+JSON.stringify(value))
  return this.http.post("http://localhost:5055/login",value).map((res:Response)=>res);

 
}

}

