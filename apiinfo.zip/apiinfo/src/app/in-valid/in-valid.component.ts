import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-in-valid',
  templateUrl: './in-valid.component.html',
  styleUrls: ['./in-valid.component.css']
})
export class InValidComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
