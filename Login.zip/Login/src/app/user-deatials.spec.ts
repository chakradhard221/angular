import { UserDeatials } from './user-deatials';

describe('UserDeatials', () => {
  it('should create an instance', () => {
    expect(new UserDeatials()).toBeTruthy();
  });
});
