import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-preview',
  templateUrl: './preview.component.html',
  styleUrls: ['./preview.component.css']
})
export class PreviewComponent implements OnInit {
 finalData:any
  constructor(private service:EmployeeService) { }

  ngOnInit() {
    // console.log("am from preview")
    this.finalData=this.service.employee2
    console.log("from preview"+JSON.stringify(this.finalData)) 
  }




//   getDataFromService(){
// this.finalData=this.service.employee2
// alert(this.finalData)  
//   }
}
