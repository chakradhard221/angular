import { Component, OnInit } from '@angular/core';
import { MapTestService } from '../map-test.service';

@Component({
  selector: 'app-map-test',
  templateUrl: './map-test.component.html',
  styleUrls: ['./map-test.component.css']
})
export class MapTestComponent implements OnInit {
finalData:any;
  constructor(private servics:MapTestService) { }

  ngOnInit() {
  }
  public getData(){
console.log("...getData..called..");
this.finalData=this.servics.dataProcess().subscribe(data=>{
  this.finalData=JSON.stringify(data);

  console.log("...finalData.."+JSON.stringify(data))
});
  }

}
