import { Component, OnInit, Output,EventEmitter  } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
studentdata=['arun','bharath','chandu','dharma','eshwar']
  constructor() { }

  ngOnInit() {
  }

  @Output() eventData=new EventEmitter();


  fireEvent(){

    this.eventData.emit(this.studentdata)
  }

}
