import { Component, OnInit } from '@angular/core';
import { AngularRestService } from '../angular-rest.service';
// import {AngularRestService} from '/home/aswindia-23/Desktop/angularSample2/AngularWithBoot/src/app/angular-rest.service'
@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {

  constructor(private service:AngularRestService) { }

  ngOnInit() {
  }

  deleteItem(value:number){
console.log(value);
this.service.delete(value)
  }

}
