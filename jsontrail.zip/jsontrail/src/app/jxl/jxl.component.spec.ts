import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JxlComponent } from './jxl.component';

describe('JxlComponent', () => {
  let component: JxlComponent;
  let fixture: ComponentFixture<JxlComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JxlComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JxlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
