import { Component, OnInit } from '@angular/core';
import {RequestOptions, Request, RequestMethod} from '@angular/http';
@Component({
  selector: 'app-sing-up',
  templateUrl: './sing-up.component.html',
  styleUrls: ['./sing-up.component.css']
})
export class SingUpComponent implements OnInit {

  constructor() { }
  options:RequestOptions
 
  ngOnInit() {

  }
 
}
