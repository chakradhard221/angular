import { Component, OnInit } from '@angular/core';
import {AngularRestService} from '../angular-rest.service';
import { Item } from '../Item';
import { Observable } from 'rxjs/Observable';


@Component({
  selector: 'app-display-data',
  templateUrl: './display-data.component.html',
  styleUrls: ['./display-data.component.css']
})
export class DisplayDataComponent implements OnInit {
  // allItems: Observable<Item[]> ;
  final:any=null
  constructor(private service:AngularRestService) { }

  ngOnInit() {


  }
displayDTA(){
  this.final=this.service.jsondata;
  alert(JSON.stringify(this.final));
  alert(".......................")
  alert(JSON.stringify(this.service.jsondata))

}
  
}
