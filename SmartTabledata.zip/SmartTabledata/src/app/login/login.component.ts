import { Component, OnInit } from '@angular/core';
import { ProfileService } from '../profile.service';
import { Router } from '@angular/router';
import { Alert } from 'selenium-webdriver';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
private access_token:any;
  constructor(private profileService:ProfileService,private routers:Router) { }

  ngOnInit() {

  }

 ckd(value:any){
   console.log("...ckdClling....");
   alert(" cnhdhdhdddh..."+JSON.stringify(value))
   
   this.profileService.getToken(value).subscribe(data=>{
      alert("...data...."+data)
      console.log("..dataToken...."+data['access_token'])
      this.access_token=data['access_token'];
    alert("..finally.tokenValue..."+this.access_token);

      if(this.access_token==null){
        alert("..going to navigate login..token Null.")
        
        this.routers.navigate['/login']
        alert("....doneLogin...")
          }
          else{
            alert("...going to dashboard");
        this.routers.navigate['/dashboard'];
        alert("..done dashboard..")
          }
    });
  //  alert("......onSubmit...."+value.json())

  
  
}

}
