import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
// import 'rxjs/Rx';
import {  HttpResponse } from '@angular/common/http';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { NgxXml2jsonService } from 'ngx-xml2json';
import { stringify } from 'querystring';

@Component({
  selector: 'app-ssl',
  templateUrl: './ssl.component.html',
  styleUrls: ['./ssl.component.css']
})
export class SSLComponent implements OnInit {

  constructor(private http_client:HttpClient,private ngxConv:NgxXml2jsonService) { }
     
  finalData;

  ngOnInit() {

  }


  submitHandler(data){
alert("..onclick..called...")
let headrs= new HttpHeaders({ 'Content-Type': 'application/json','Access-Control-Allow-Origin':'*'});

let options = {
  headers: headrs
}
  //  this.http_client.options("https://uat.nsenmf.com/NMFIIService/NMFService/State?BrokerCode=ARN-82172&Appln_Id=MFS82172&Password=Admin@12"
  //  ).subscribe(data=>console.log("dataFromHttpsReq...."+data));
    // let url="https://app.solitx.io:5050/ProfilesService/profiles?access_token="
    // let exUrl="https://localhost:5002/list"
    let exUrl="/NMFIIService/NMFService/State?BrokerCode=ARN-82172&Appln_Id=MFS82172&Password=Admin@12"
    this.http_client.get(exUrl).subscribe((data)=>{
alert(data)
      let fg=JSON.stringify(data)
      var parser=new DOMParser();
      //  var xmlDoc=parser.parseFromString(fg,"text/xml");
       var obj=this.ngxConv.xmlToJson(parser.parseFromString(fg,"text/xml"))
       alert("finalJson..."+JSON.stringify(obj))
      console.log("...data.."+JSON.stringify(obj))
      this.finalData=JSON.stringify(data)
      });
    // let varHeader=;
     }

  // 
  ssubmitHandler(data){
    let exUrl="https://dev.solitx.io:7766/transactiondetails";
    alert("postCalling..")
this.http_client.post(exUrl, {
  "from_date": "01-Nov-2019",
  "to_date": "08-Jan-2020",
  "iin": "5011219540"
}).subscribe(cons=>console.log(cons));
  }

  ssubmitHandlers(data){
    let exUrl="http://localhost:4200/NMFIIService/NMFService/State?BrokerCode=ARN-82172&Appln_Id=MFS82172&Password=Admin@12"
    this.http_client.get(exUrl).subscribe((res:Response)=>console.log(res));
  }


//   "/NMFIIService/NMFService/*":{
//     "target":{
//         "host": "uat.nsenmf.com",
//         "protocol": "https:"
//     },
//      "secure": false,
//  "changeOrigin": true,
//  "logLevel": "debug"
// }

 // "/transactiondetails/":{
    //     "target":{
    //         "host": "dev.solitx.io",
    //         "protocol": "https:",
    //         "port":7766
    //     },
    //      "secure": false,
    //  "changeOrigin": true,
    //  "logLevel": "debug"
    // },

}
