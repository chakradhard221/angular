import { Component, OnInit } from '@angular/core';
import { Person } from './Person';
import { ArraySam } from './ArraySam';

@Component({
  selector: 'app-loops',
  templateUrl: './loops.component.html',
  styleUrls: ['./loops.component.css']
})
export class LoopsComponent implements OnInit {

  constructor(private personsList: ArraySam) { }
  i:any
  subs = [];
  ngOnInit() {
  }

  getData() {
    this.subs = this.personsList.persons
    console.log(this.subs);
  }
 sentData(){
   for(this.i=0;this.i<this.subs.length;this.i++){
    console.log("......."+this.subs[this.i].name)
   }
 }

}



