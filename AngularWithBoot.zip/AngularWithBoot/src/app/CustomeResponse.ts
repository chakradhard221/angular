export class CustomeResponse{
status:number
message:string

}