
export class ArraySam{
 myList:Array<Object>=[
{name:"sarat",number:150},
{name:"madhu",number:151}
]
}