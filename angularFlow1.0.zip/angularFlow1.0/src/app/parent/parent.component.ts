import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {
jsonObj:any
  constructor() { }

  ngOnInit() {
  }



  receiveData(value:any){
  alert("......parentData....."+JSON.stringify(value))
this.jsonObj=value

  }

}
