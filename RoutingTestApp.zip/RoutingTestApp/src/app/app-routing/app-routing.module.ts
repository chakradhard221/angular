import { NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes, RouterModule} from '@angular/router';
import {SingUpComponent} from '../sing-up/sing-up.component';
import {LoginComponent} from '../login/login.component';


export const routes:Routes=[
{path:'signgo' ,component:SingUpComponent},
{path:'logingo',component:LoginComponent}
]

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],

  exports:[
    RouterModule
  ],
  declarations: []
})
export class AppRoutingModule { 



}
