import { Component, OnInit } from '@angular/core';
import { analyzeAndValidateNgModules } from '@angular/compiler';
import * as JsonToXML from 'js2xmlparser';

@Component({
  selector: 'app-jsonxml',
  templateUrl: './jsonxml.component.html',
  styleUrls: ['./jsonxml.component.css']
})
export class JsonxmlComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }


  submitData(value){
alert(JSON.stringify(value));
alert(JsonToXML.parse("emp","value"))
  }

}
