import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Rx';
import { CustomeError } from '../app/CustomeError';
import { CustomeResponse } from '../app/CustomeResponse';
import { Item } from '../app/Item';


@Injectable()
export class AngularRestService {
  jsondata: any;
  cart:Item[];

  constructor(private _http: HttpClient) { }

  createItem(value: any) {
    // const url = 'http://localhost:5050/UserService/users/root';
    const url = 'http://localhost:9007/create';
    // const body = {
    //   "Entity Legal Form": "LLC", "Entity Banner": "AriadneTPS", "Entity Address": "india", "Identifier": "aswindia121021", "Root Password": "$2a$08$D1vb8lTyY.6zFDjMYluqw.JVkcz1JQvR26uz6zOHhXFEQ69CYdiA6", "FormLabel": "RootUser", "Entity Logo": "",
    //   "Root Email": "asw@gmail.com", "Entity Country": "india", "Entity Name": "Ariadne"
    // }
    let db = this._http.post(url,value);
    // db.map((res: Response) => res.json()).catch(this.errorHandler).subscribe();
    db.map((res: CustomeResponse) => console.log(res)).catch(this.errorHandler).subscribe();
    alert("service..JsonData.........")
  }


  
  update(updateValue: any) {
    alert(JSON.stringify(updateValue));
    // here itemID and itemClass properties must be same as ItemEntity class
    let db = this._http.put("http://localhost:9007/update/" + updateValue["itemId"], updateValue);
    db.subscribe(res => (console.log(res)));
  }

  delete(deletevalue: number) {
    alert(JSON.stringify(deletevalue));
    //  here from deleteValue we get number value (deleteValue["number"]....)
    let db = this._http.delete("http://localhost:9007/remove/" + deletevalue["number"]);
    db.subscribe(res => (console.log(res)));
  }

  provideAllData():Observable<Item[]> {
    alert(".......service.........")

    // const url="http://localhost:9007/data";
const url="https://localhost:9000/first";
 return this._http.get(url).map((res:Response)=>res.json()).catch((error:any)=>Observable.throw('server error'));

  //  return  db.subscribe(res=>console.log(res));
    
  }


  profileData(data:any){


    const url="http://localhost:8001/profile"

    let db=this._http.post(url,data)


  }

  errorHandler(error: CustomeError) {
    if (error.status == 406) {
      alert(error.status);
      alert(JSON.stringify(error.error))
      // window.open('/', '_self');
    }

    else {
      if (error.status == 400) {
        alert(error.status);
        alert(JSON.stringify(error.error.message))
      }
      else {
        // window.open('/', '_self');
      }
    }
    return Observable.throw(error || " server error ");
  }
}
