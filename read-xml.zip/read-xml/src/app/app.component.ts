import { Component } from '@angular/core';
import xml2js from 'xml2js';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { resolve } from 'url';
import {NgxXml2jsonService} from 'ngx-xml2json';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'read-xml';


  public xmlItems: any;
  public headerqw:any 
  constructor(private _http: HttpClient,private ngxConv:NgxXml2jsonService) { this.loadXML(); }


  loadXML() {

    {
      this.headerqw= new HttpHeaders()
        .set('Content-Type', 'text/xml')
        .append('Access-Control-Allow-Methods', 'GET')
        .append('Access-Control-Allow-Origin', '*')
        .append('Access-Control-Allow-Headers', "Access-Control-Allow-Headers, Access-Control-Allow-Origin, Access-Control-Request-Method")
     
    }
alert (JSON.stringify(this.headerqw))
    this._http.get('/assets/emp.xml',
      {
        headers: new HttpHeaders()
          .set('Content-Type', 'text/xml')
          .append('Access-Control-Allow-Methods', 'GET')
          .append('Access-Control-Allow-Origin', '*')
          .append('Access-Control-Allow-Headers', "Access-Control-Allow-Headers, Access-Control-Allow-Origin, Access-Control-Request-Method"),
        responseType: 'text'
      })
      .subscribe((data) => {
    var parser=new DOMParser();
     var xmlDoc=parser.parseFromString(data,"text/xml");
     var obj=this.ngxConv.xmlToJson(xmlDoc);
     alert("..."+obj['Employee']['emp']);
    this.xmlItems = obj['Employee']['emp'];
      });
  }



  settings={
    columns:{
      id:{
        title:'ID'
      },
      name:{
        title:'Name'
      },
      gender:{
        title:'Gender'
      },
      mobile:{
        title:'Mobile'
      }
    }
  }
}

