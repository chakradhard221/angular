import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { WalletComponent } from './wallet/wallet.component';
import { BankAccountComponent } from './bank-account/bank-account.component';
import { AppRoutingModule } from './app-routing/app-routing.module';
import {RouterModule,Router} from '@angular/router'

@NgModule({
  declarations: [
    AppComponent,
    WalletComponent,
    BankAccountComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
