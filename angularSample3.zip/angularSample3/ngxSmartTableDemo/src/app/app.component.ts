import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable} from 'rxjs';
import { PagerService } from 'PagerService';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  constructor(private http: HttpClient, private pagerService: PagerService) {

  }

  title = 'ngxSmartTableDemo';
  private allItems: any[];

  // pager object
  pager: any = {};

  // paged items
  pagedItems: any[];


  ngOnInit() {
   let db= this.http.get('./dummy-data.json');
   db.map((res: Response) => console.log(res)
  }



  setPage(page: number) {
    // get pager object from service
    this.pager = this.pagerService.getPager(this.allItems.length, page);

    // get current page of items
    this.pagedItems = this.allItems.slice(this.pager.startIndex, this.pager.endIndex + 1);
}
}
