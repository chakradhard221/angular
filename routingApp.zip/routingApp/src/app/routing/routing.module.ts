import { NgModule, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Routes, Router, RouterModule } from '@angular/router';
import {LoginComponent} from 'src/app/login/login.component';
import { SignUPComponent } from '../sign-up/sign-up.component';

const routes:Routes=[
  {path:'Login',component:LoginComponent},
  {path:'USer', component:SignUPComponent}
]


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
  RouterModule.forRoot(routes)
  ],
  exports:[
    RouterModule
  ]
})



export class RoutingModule {

 }
