import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import {ProfileEditorComponent} from '../app/profile-editor/profile-editor.component'
import { UserForm } from './UserForm';
import { HttpClientModule              } from '@angular/common/http';
@Injectable()
export class CreateUserService {

  constructor(private _http:HttpClient) { }

  url:string="http://localhost:9000/store";

createUser(user:any){

  alert("userstring...."+JSON.stringify(user))
 

 let db = this._http.post(this.url,user);
 db.subscribe()
}
getUser(){
 let db=this._http.get("http://localhost:9000/get");
 db.subscribe();
 
}
}
