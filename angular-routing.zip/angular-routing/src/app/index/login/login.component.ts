import { Component, OnInit } from '@angular/core';
import { Jsonp } from '@angular/http';
import {AuthService} from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  public postData={
    'email':'',
    'password':''
  }
  public errorText='';
  constructor(private authServices:AuthService,private router:Router) { }

  ngOnInit() {
  }
  loginAction(){
    if(this.postData.email&&this.postData.password){
this.errorText='';
if(this.authServices.login(this.postData)){
  this.router.navigate(['']);
};
    }else{
      this.errorText='please enter valid Data';
    }
    console.log("....."+JSON.stringify(this.postData));
  
   }
}
