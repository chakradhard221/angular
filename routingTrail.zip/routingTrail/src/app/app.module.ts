import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BankComponent } from './bank/bank.component';
import { SignupComponent } from './signup/signup.component';
import { RoutModule } from './rout/rout.module';


@NgModule({
  declarations: [
    AppComponent,
    BankComponent,
    SignupComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RoutModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
