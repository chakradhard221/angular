import { Component, OnInit, Output,EventEmitter } from '@angular/core';


@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {


  jsonData:any;
  constructor() { }

  ngOnInit() {
  }


  @Output() public valueObject=new EventEmitter()

  
  getData(){
    alert("...ForwardingData..."+JSON.stringify(this.jsonData))
    this.valueObject.emit(this.jsonData)
  }

  postData(value:any){
    alert("........Data.From Form...."+JSON.stringify(value))
    this.jsonData=value
  }

}
