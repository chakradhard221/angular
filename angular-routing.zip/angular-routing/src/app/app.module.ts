import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { IndexComponent } from './index/index.component';
import { HomeComponent } from './home/home.component';
import { NoPageComponent } from './no-page/no-page.component';
import { RouterModule } from '@angular/router';
import {routes} from './app.router';
import {HomeModule} from './home/home.module';
import {IndexModule} from './index/index.module';
import {AuthService} from './services/auth.service';
import {AuthGuard} from './guards/auth.guard';
import {LoginGuard } from './guards/login.guard';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    IndexComponent,
    HomeComponent,
    NoPageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    IndexModule,
    HomeModule,
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [AuthGuard ,AuthService,LoginGuard ],
  bootstrap: [AppComponent]
})
export class AppModule { }
