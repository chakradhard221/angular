import { Component, OnInit } from '@angular/core';
import { ProfileService } from '../profile.service';
import { LocalDataSource } from 'ng2-smart-table';
// import 'rxjs/Observable';

@Component({
  selector: 'app-profile-data',
  templateUrl: './profile-data.component.html',
  styleUrls: ['./profile-data.component.css']
})
export class ProfileDataComponent implements OnInit {
source:LocalDataSource=new LocalDataSource();
smartTableLoadData = [];

settings={

  // actions: { add: false, edit: false, delete: false}
  
columns:{

ProfileID:{
  title:'ProfileID',
  type:'string'
},
status:{
title:'status',
type:'string'
},
Identifier: {
title:'Identifier'
 
},
progress:{
title:'progress',
type:'string',
}
}
};

  constructor(private profileService: ProfileService) { }

  ngOnInit() {
    alert('...data...getBack..')
    // this.profileService.provideData();
    // this.profileService.postData();
    this.profileService.provideData().subscribe((data) => {
      alert("...dataCompomnenet.."+data);
      data.forEach(element => {
        console.log("...elemnt..." + element['status'])

        this.smartTableLoadData.push({
          "ProfileID": element['ProfileID'],
          "status":element['status'],
          "Identifier": element['profileDetails']['Identifier'],
          "progress":"true"
        })

      });

      this.source.load(this.smartTableLoadData);
      alert("...sname..." + data['name']);


    })

  }

}
