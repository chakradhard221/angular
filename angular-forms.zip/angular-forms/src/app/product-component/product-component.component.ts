import { Component, OnInit } from '@angular/core';
import { Product } from '../product';

@Component({
  selector: 'app-product-component',
  templateUrl: './product-component.component.html',
  styleUrls: ['./product-component.component.css']
})
export class ProductComponentComponent implements OnInit {
  productsSpec = ['Really Smart', 'Super Flexible',
            'Super Hot', 'Weather Changer'];
model=new Product(10,"chandu","good");
submitted=false;

onSubmit(){
  this.submitted=true
}

getDiagnostic(){
  alert(this.model)
  return JSON.stringify(this.model);
}
  constructor() { }

  ngOnInit() {
  }

}
