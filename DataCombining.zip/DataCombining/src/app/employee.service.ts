import { Injectable } from '@angular/core';
import { AngularWaitBarrier } from 'blocking-proxy/built/lib/angular_wait_barrier';
import { $, $$ } from 'protractor';

@Injectable()
export class EmployeeService {

  constructor() { }
  array=new Array();
employee:any
employee2:any
finalObject
firstCompData(value:any){
alert(".......firstService1..."+value.name)

this.employee=value;
Object.assign(this.employee,this.employee2)
}


secondCompData(value:any){
  alert(".......secondService1..."+value)
 this.employee2=value
 this.employee2=Object.assign(this.employee,this.employee2)
 alert(JSON.stringify(this.employee2))
}


}
