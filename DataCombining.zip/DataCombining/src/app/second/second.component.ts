import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-second',
  templateUrl: './second.component.html',
  styleUrls: ['./second.component.css']
})
export class SecondComponent implements OnInit {
  // hiddenForm = false;
  constructor( private router:Router,private service:EmployeeService) {

  }

  ngOnInit() {

  }

  onSubmit(value: any) {
    // this.hiddenForm=true
    alert(".........secondComponenent........"+JSON.stringify(value))
    console.log(JSON.stringify(value))
this.service.secondCompData(value);
    this.router.navigate(['preview']);
  }
}
