import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { ProfileDataComponent } from './profile-data/profile-data.component';
import {NgxPaginationModule} from 'ngx-pagination';
import { HttpClientModule } from '@angular/common/http';
import { ProfileService } from './profile.service';
import { StudentComponent } from './student/student.component';
import { LoginComponent } from './login/login.component';
import {FormsModule} from '@angular/forms';
import { RouterModule } from '@angular/router';
import {NavigationModule} from './navigation/navigation.module';
import { DashBoardComponent } from './dash-board/dash-board.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

@NgModule({
  declarations: [
    AppComponent,
    ProfileDataComponent,
    StudentComponent,
    LoginComponent,
    DashBoardComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule,
    Ng2SmartTableModule,
    NgxPaginationModule,
    HttpClientModule,
    FormsModule,
    RouterModule,
    NavigationModule
    
  
  ],
  providers: [ProfileService],
  bootstrap: [AppComponent]
})
export class AppModule { }
