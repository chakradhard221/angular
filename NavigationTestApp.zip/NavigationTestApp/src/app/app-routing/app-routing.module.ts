import { NgModule, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { WalletComponent } from '../wallet/wallet.component';
import { BankAccountComponent } from '../bank-account/bank-account.component';

export const routes:Routes=[
  {'path':"wallet",component:WalletComponent},
  {'path':"bank", component:BankAccountComponent}
]
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  exports:[
  RouterModule

  ],
  declarations: []
})
export class AppRoutingModule { }
