import { Injectable } from '@angular/core';
import { async } from '@angular/core/testing';
import localeFr from '@angular/common/locales/fr';

@Injectable()
export class AuthService {

  constructor() { }

public isAuthenticated():boolean{

const userData=sessionStorage.getItem('userData');
if(userData&&userData.length>0){
return true;
}else{
  
  return true;
}

}


public async getUserData(){
  const userData= await sessionStorage.getItem('userData');
return JSON.parse(userData);
}


public async login(postData){


const responseData={
  'name':'chakradhar',
  'number':'9703229090',
  'token':'123qwerfgvb'
}
await sessionStorage.setItem('userData',JSON.stringify(responseData));
console.log('...servce...'+sessionStorage.getItem('userData'))
return true;
}
public signup(postData){

}
public async logout(postData){
await sessionStorage.removeItem('userData');
console.log("...sessiomRemove.."+sessionStorage);

await sessionStorage.clear();
return true;
}
}
