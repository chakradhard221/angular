import { Component, OnInit } from '@angular/core';
import { ProfileService } from '../profile.service';
import { LocalDataSource } from 'ng2-smart-table';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {

  dataSource:LocalDataSource=new LocalDataSource();
  smartTableLoadData = [];
settings={
columns:{
  studentID:{
    'title':"studentID",
    'type':'string'
  },
  studentName:{
    'title':"studentName",
    'type':'string'
  }
}

}




  constructor(private service:ProfileService) { }

  ngOnInit() {
alert("....dataget...")
this.service.getData().subscribe(data=>{
  data.forEach(element =>{
    alert("elemnt....."+element['sid']);
    alert("elemnt....."+element['name']);
this.smartTableLoadData.push({
"studentID":element['sid'],
"studentName":element['name']
})

});
this.dataSource.load(this.smartTableLoadData)
})

}
}
