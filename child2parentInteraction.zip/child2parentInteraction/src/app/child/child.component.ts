import { Component, OnInit, Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }


stringData=['anil','bharath','chandu','dharma','eshawar']

@Output() public post=new EventEmitter();
postData(){
alert("child..................."+this.stringData)
this.post.emit(this.stringData)
}

}
