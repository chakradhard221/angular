import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
// import { Observable } from 'rxjs/Observable';
import {AuthService} from "../services/auth.service";
@Injectable()
export class LoginGuard implements CanActivate {

  constructor(public authServices:AuthService,public router:Router){}

  canActivate():boolean{
    if(!this.authServices.isAuthenticated()){
     this.router.navigate(['']);
      return false;
    }
    return true;
  }
}
