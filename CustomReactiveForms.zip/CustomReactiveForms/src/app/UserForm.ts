export class UserForm{

    uno:number
    name:string
    phone:string
    age:string
}