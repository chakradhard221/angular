import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'
import {RouterModule} from "@angular/router"
import { AppComponent } from './app.component';
import { FirstComponent } from './first/first.component';
import { SecondComponent } from './second/second.component';
import {ConfigModule} from '/home/aswindia-23/Desktop/angularSample2/DataCombining/src/app/config/config.module';
import { PreviewComponent } from './preview/preview.component';
import { HomeComponent } from './home/home.component';
import {EmployeeService} from '/home/aswindia-23/Desktop/angularSample2/DataCombining/src/app/employee.service'


@NgModule({
  declarations: [
    AppComponent,
    FirstComponent,
    SecondComponent,
    PreviewComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule,
    ConfigModule
  ],
  providers: [EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
