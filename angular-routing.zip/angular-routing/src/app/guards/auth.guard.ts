import { Injectable } from '@angular/core';
import { CanActivate, Router, RouterModule } from '@angular/router';

// import { Observable } from 'rxjs/Observable';
import {AuthService} from '../services/auth.service';
@Injectable()
export class AuthGuard implements CanActivate {
 
  constructor(private  authServices:AuthService,private  router:Router){}

canActivate():boolean{
  if(!this.authServices.isAuthenticated()){
this.router.navigate(['login']);
    return false;
  }else{
    return true;
  }
}
}
