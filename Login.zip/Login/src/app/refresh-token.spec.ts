import { RefreshToken } from './refresh-token';

describe('RefreshToken', () => {
  it('should create an instance', () => {
    expect(new RefreshToken()).toBeTruthy();
  });
});
