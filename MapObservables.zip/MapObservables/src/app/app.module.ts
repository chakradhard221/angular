import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { MapTestComponent } from './map-test/map-test.component';
import { HttpClientModule } from '@angular/common/http';
import { MapTestService } from './map-test.service';


@NgModule({
  declarations: [
    AppComponent,
    MapTestComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule
  ],
  providers: [MapTestService],
  bootstrap: [AppComponent]
})
export class AppModule { }
