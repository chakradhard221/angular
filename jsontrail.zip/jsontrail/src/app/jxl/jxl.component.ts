import { Component, OnInit } from '@angular/core';
import * as JsonToXML from 'js2xmlparser';
import { FormControl } from '@angular/forms';
import { NgxXml2jsonService } from 'ngx-xml2json';
import { error } from 'selenium-webdriver';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-jxl',
  templateUrl: './jxl.component.html',
  styleUrls: ['./jxl.component.css']
})
export class JxlComponent implements OnInit {
  email=new FormControl('');
  xmlData:any;
  constructor(private http_client:HttpClient){}

  ngOnInit() {
    
  }

//   goThere(val){
// alert(JSON.stringify(val))
// alert(JsonToXML.parse('data',val));
//   }

updateEmail(data){
  alert('...cld....'+data)
  this.email.setValue('chakradhar@gmail.com');
      // alert('called..'+JsonToXML.parse('email',data))
}

getXml(){
  var data:any={
    name:"chakradhar",
    mobi:"9632587410"
  }
  alert("..mydata.."+JSON.stringify(data))
  alert("aboveData...")
alert("..JSON...."+data)
  // this.http  alert("aboveData...")
    // var js2xmlparser = require("js2xmlparser");
  // js2xmlparser.parse("person", data);
}
}