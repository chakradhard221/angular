import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
names:any=null;
//   displayCounter(count) {
//     alert('............parent')
//     console.log(count);
// }


getData(value:any){

alert("........parent...."+value)
this.names=value


}


}
