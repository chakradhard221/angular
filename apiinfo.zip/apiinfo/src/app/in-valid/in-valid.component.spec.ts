import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InValidComponent } from './in-valid.component';

describe('InValidComponent', () => {
  let component: InValidComponent;
  let fixture: ComponentFixture<InValidComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InValidComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InValidComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
